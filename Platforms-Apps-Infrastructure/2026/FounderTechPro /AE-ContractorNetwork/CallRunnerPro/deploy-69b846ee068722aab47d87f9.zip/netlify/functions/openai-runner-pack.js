const pdfParse = require('pdf-parse');
const mammoth = require('mammoth');

function json(statusCode, body) {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store'
    },
    body: JSON.stringify(body)
  };
}

function cleanText(text) {
  return String(text || '')
    .replace(/\u0000/g, ' ')
    .replace(/\r/g, '')
    .replace(/\t/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .replace(/[ \u00A0]{2,}/g, ' ')
    .trim();
}

function extractOutputText(responseJson) {
  if (typeof responseJson?.output_text === 'string' && responseJson.output_text.trim()) {
    return responseJson.output_text;
  }
  const outputs = Array.isArray(responseJson?.output) ? responseJson.output : [];
  for (const item of outputs) {
    const content = Array.isArray(item?.content) ? item.content : [];
    for (const part of content) {
      if ((part?.type === 'output_text' || part?.type === 'text') && typeof part?.text === 'string') {
        return part.text;
      }
    }
  }
  return '';
}

async function extractSource(source) {
  const type = String(source?.type || '').toLowerCase();
  const name = String(source?.name || 'source');

  if ((type === 'txt' || type === 'md') && source?.text) {
    return { name, type, text: cleanText(source.text) };
  }

  if ((type === 'pdf' || type === 'docx') && source?.base64) {
    const buffer = Buffer.from(String(source.base64), 'base64');
    if (type === 'pdf') {
      const parsed = await pdfParse(buffer);
      return { name, type, text: cleanText(parsed?.text || '') };
    }
    if (type === 'docx') {
      const parsed = await mammoth.extractRawText({ buffer });
      return { name, type, text: cleanText(parsed?.value || '') };
    }
  }

  if (source?.text) {
    return { name, type: type || 'txt', text: cleanText(source.text) };
  }

  return { name, type: type || 'txt', text: '' };
}

function buildMergedText(sources) {
  return cleanText(
    sources
      .filter((src) => src.text)
      .map((src) => `===== ${src.name} (${src.type.toUpperCase()}) =====\n${src.text}`)
      .join('\n\n')
  );
}

function buildSchema() {
  return {
    name: 'runner_pack',
    strict: true,
    schema: {
      type: 'object',
      additionalProperties: false,
      required: ['meta', 'settingsPatch', 'steps', 'templates', 'assessment', 'masterScriptIntro'],
      properties: {
        meta: {
          type: 'object',
          additionalProperties: false,
          required: ['name', 'version', 'sourceNames'],
          properties: {
            name: { type: 'string' },
            version: { type: 'string' },
            sourceNames: { type: 'array', items: { type: 'string' } }
          }
        },
        settingsPatch: {
          type: 'object',
          additionalProperties: false,
          required: ['goal', 'tiers', 'repName', 'repSig', 'sendTo'],
          properties: {
            goal: { type: 'string' },
            tiers: { type: 'string' },
            repName: { type: 'string' },
            repSig: { type: 'string' },
            sendTo: { type: 'string' }
          }
        },
        steps: {
          type: 'array',
          minItems: 1,
          items: {
            type: 'object',
            additionalProperties: false,
            required: ['key', 'title', 'desc', 'script', 'choices'],
            properties: {
              key: { type: 'string' },
              title: { type: 'string' },
              desc: { type: 'string' },
              script: { type: 'string' },
              choices: {
                type: 'array',
                items: {
                  type: 'object',
                  additionalProperties: false,
                  required: ['id', 'label', 'next', 'lane', 'status', 'callOutcome', 'setTier', 'complete'],
                  properties: {
                    id: { type: 'string' },
                    label: { type: 'string' },
                    next: { type: 'string' },
                    lane: { type: 'string' },
                    status: { type: 'string' },
                    callOutcome: { type: 'string' },
                    setTier: { type: 'string' },
                    complete: { type: 'boolean' }
                  }
                }
              }
            }
          }
        },
        templates: {
          type: 'array',
          items: {
            type: 'object',
            additionalProperties: false,
            required: ['key', 'label', 'content'],
            properties: {
              key: { type: 'string' },
              label: { type: 'string' },
              content: { type: 'string' }
            }
          }
        },
        assessment: {
          type: 'object',
          additionalProperties: false,
          required: ['subject', 'headline', 'body'],
          properties: {
            subject: { type: 'string' },
            headline: { type: 'string' },
            body: { type: 'string' }
          }
        },
        masterScriptIntro: { type: 'string' }
      }
    }
  };
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return json(405, { ok: false, error: 'Method not allowed.' });
  }

  if (!process.env.OPENAI_API_KEY) {
    return json(500, { ok: false, error: 'OPENAI_API_KEY is not configured.' });
  }

  try {
    const decodedBody = event.isBase64Encoded
      ? Buffer.from(event.body || '', 'base64').toString('utf-8')
      : (event.body || '{}');
    const body = JSON.parse(decodedBody || '{}');
    const rawSources = Array.isArray(body?.sources) ? body.sources.slice(0, 10) : [];
    const instructions = cleanText(body?.instructions || '');
    const existingSettings = body?.existingSettings && typeof body.existingSettings === 'object' ? body.existingSettings : {};
    const parserConfig = body?.parserConfig && typeof body.parserConfig === 'object' ? body.parserConfig : {};

    if (!rawSources.length) {
      return json(400, { ok: false, error: 'No sources were provided.' });
    }

    const extractedSources = [];
    for (const source of rawSources) {
      const extracted = await extractSource(source);
      if (extracted.text) extractedSources.push(extracted);
    }

    const mergedText = buildMergedText(extractedSources);
    if (!mergedText || mergedText.length < 40) {
      return json(400, { ok: false, error: 'Source extraction returned too little text to build a runner pack.' });
    }

    const model = cleanText(parserConfig?.modelOverride || process.env.OPENAI_SCRIPT_MODEL || 'gpt-4.1-mini').slice(0, 120) || 'gpt-4.1-mini';
    const defaultSystemPrompt = [
      'You convert sales scripts and offer materials into a reusable AE call-runner pack.',
      'Output only structured JSON that conforms to the provided schema.',
      'Preserve the source offer and do not hallucinate impossible claims.',
      'Use placeholders only from this approved set when needed: {{company}}, {{contact}}, {{phone}}, {{email}}, {{website}}, {{industry}}, {{nextFollowUp}}, {{repName}}, {{repSig}}, {{sendTo}}, {{goal}}, {{tierInterest}}, {{priorityPages}}, {{gapSummary}}.',
      'Design the steps so a rep can click through them inside one console. Include gatekeeper handling, objection handling, voicemail or fallback, and post-call next-step handling when the source supports it.',
      'Every choice must include a next field. Use an empty string only when the natural action is to continue linearly to the next step.',
      'Keep scripts dense and directly usable. Avoid commentary, analysis, or markdown fences.'
    ].join('\n');
    const systemPrompt = cleanText(parserConfig?.systemPromptOverride || defaultSystemPrompt) || defaultSystemPrompt;

    const userPrompt = [
      `Existing settings:\n${JSON.stringify(existingSettings, null, 2)}`,
      instructions ? `Operator instructions:\n${instructions}` : 'Operator instructions: none supplied.',
      `Source names: ${extractedSources.map((s) => s.name).join(', ')}`,
      'Source material:',
      mergedText.slice(0, 120000)
    ].join('\n\n');

    const payload = {
      model,
      store: false,
      input: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ],
      max_output_tokens: 6000,
      text: {
        format: {
          type: 'json_schema',
          ...buildSchema()
        }
      }
    };

    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify(payload)
    });

    const raw = await response.text();
    let responseJson = null;
    try {
      responseJson = JSON.parse(raw);
    } catch {
      responseJson = null;
    }

    if (!response.ok) {
      const message = responseJson?.error?.message || raw || `OpenAI request failed (${response.status}).`;
      return json(response.status, { ok: false, error: message });
    }

    const outputText = extractOutputText(responseJson);
    if (!outputText) {
      return json(502, { ok: false, error: 'OpenAI returned no structured output text.' });
    }

    let runnerPack;
    try {
      runnerPack = JSON.parse(outputText);
    } catch (error) {
      return json(502, {
        ok: false,
        error: `OpenAI returned invalid JSON: ${error.message}`,
        raw: outputText.slice(0, 4000)
      });
    }

    runnerPack.settingsPatch = {
      goal: String(runnerPack?.settingsPatch?.goal || existingSettings.goal || ''),
      tiers: String(runnerPack?.settingsPatch?.tiers || existingSettings.tiers || ''),
      repName: String(runnerPack?.settingsPatch?.repName || existingSettings.repName || ''),
      repSig: String(runnerPack?.settingsPatch?.repSig || existingSettings.repSig || ''),
      sendTo: String(runnerPack?.settingsPatch?.sendTo || existingSettings.sendTo || '')
    };

    return json(200, {
      ok: true,
      usedModel: model,
      mergedText: mergedText.slice(0, 50000),
      sourceSummaries: extractedSources.map((s) => ({ name: s.name, type: s.type })),
      runnerPack
    });
  } catch (error) {
    return json(500, { ok: false, error: error.message || 'Unexpected function error.' });
  }
};
