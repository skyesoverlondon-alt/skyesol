SIGIL COUNCIL RUNNER PACK STUDIO V3

Fixes included:
- Base64 request body decoding for Netlify Functions
- Strict JSON schema fix for settingsPatch
- Browser-side Parser Control (model override + system prompt override)
- Full package with manifest, icons, service worker, index, function, and env example

Deploy via Netlify CLI from the extracted folder root.
