const CACHE_NAME = 'sigil_runner-v5';
const CORE_ASSETS = [
  "./",
  "./Sigil-Council-console.html",
  "./manifest.json",
  "./icon-192.png",
  "./icon-512.png"
];

self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return Promise.all(
        CORE_ASSETS.map(url => {
          return cache.add(url).catch(err => console.warn('Cache add failed:', url));
        })
      );
    })
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(clients.claim());
});

self.addEventListener('fetch', (event) => {
  if (!event.request.url.startsWith('http')) return;

  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      if (cachedResponse) return cachedResponse;

      return fetch(event.request, { mode: 'no-cors' }).then((networkResponse) => {
        const isValid = networkResponse && (
            networkResponse.status === 200 || 
            networkResponse.status === 0 || 
            networkResponse.type === 'opaque'
        );

        if (isValid) {
            const responseToCache = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(event.request, responseToCache);
            });
        }
        return networkResponse;
      }).catch(() => null);
    })
  );
});